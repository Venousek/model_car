/**
 *
 * Standard includes.
 *
 * @file
 * Copyright &copy; Audi Electronics Venture GmbH. All rights reserved
 *
 * $Author: martin.heimlich $
 * $Date: 2008-07-22 11:00:19 +0200 (Di, 22 Jul 2008) $
 * $Revision: 3883 $
 *
 * @remarks
 *
 */
#include "stdafx.h"
