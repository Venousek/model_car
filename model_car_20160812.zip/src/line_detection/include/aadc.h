/**********************************************************************
* Copyright (c) 2013 BFFT Gesellschaft fuer Fahrzeugtechnik mbH.
* All rights reserved.
**********************************************************************
* $Author:: spiesra $  $Date:: 2014-07-11 12:34:22#$ $Rev:: 24240   $
**********************************************************************/

/*! \brief Definitionen f�r Pins und Datentypen
 *         
 *  Hier finden sich alle Definitionen f�r die Pins und Datentypen.
 */

#ifndef _AADC_H_
#define _AADC_H_


#endif // _AADC_H_
