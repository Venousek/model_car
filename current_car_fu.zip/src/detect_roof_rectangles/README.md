# detect_roof_rectangles
compile cmvision
source devel/setup.bash
install v4l-utils
