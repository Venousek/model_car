/*
 * LineSegment.h
 *
 *  Created on: Apr 7, 2014
 *      Author: 'Jannis Ihrig'
 */

#ifndef LINESEGMENT_H_
#define LINESEGMENT_H_

class LineSegment
{
public:
	LineSegment(Point start, Point end):
		start(start),
		end(end)
	{}
	virtual ~LineSegment() {};

	Point getStart() const {
		return start;
	}
	Point getEnd() const {
		return end;
	}
private:
	Point start;
	Point end;
};

#endif /* LINESEGMENT_H_ */
