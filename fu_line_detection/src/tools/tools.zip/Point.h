#ifndef POINT_H_
#define POINT_H_

#include <string>
#include <ostream>

#include "Vector.h"

/**
 * A (2-dimensional) point template, represented by its origin vector.
 *
 * Arithmetic operators are also defined to relate these points with vectors:
 * - subtracting a Point from another Point yields a Vector
 * - adding a Point and a Vector yields a Point
 * - adding a Point to another Point is not allowed
 * (like in school math)
 */
template <typename MemberType>
class Point {
public:
	Point() : Point(Vector<MemberType>()) { /* void */ }
	Point(Vector<MemberType> originVector) : originVector(originVector) { /* void */ }
	Point(MemberType x, MemberType y) : originVector(x, y) { /* void */ }

	virtual ~Point() { /* void */ }

	const Vector<MemberType>& getOriginVector() const { return originVector; }
	MemberType getX() const { return originVector.getX(); }
	MemberType getY() const { return originVector.getY(); }

	std::string toString() const {
		std::stringstream result;
		result << "Point {" << getX().value() << ", " << getY().value() << "}";
		return result.str();
	}

	Point<MemberType> operator+(const Vector<MemberType>& vector) const {
		return Point<MemberType>(*this) += vector;
	}

	Point<MemberType> operator-(const Vector<MemberType>& vector) const {
		return Point<MemberType>(*this) -= vector;
	}

	Vector<MemberType> operator-(const Point<MemberType>& other) const {
		return this->originVector - other.originVector;
	}

	bool operator==(const Point& other) const {
		return this->originVector == other.originVector;
	}

	bool operator!=(const Point& other) const {
		return !(*this == other);
	}

	Point<MemberType>& operator+=(const Vector<MemberType>& vector) {
		this->originVector += vector;
		return *this;
	}

	Point<MemberType>& operator-=(const Vector<MemberType>& vector) {
		this->originVector -= vector;
		return *this;
	}

	friend std::ostream& operator<<(std::ostream& stream, const Point<MemberType>& point) {
		stream << point.getOriginVector();
		return stream;
	}

	friend std::istream& operator>>(std::istream& stream, Point<MemberType>& point) {
		stream >> point.originVector;
		return stream;
	}

private:
	Vector<MemberType> originVector;
};

template <typename MemberType>
Point<MemberType> operator+(const Vector<MemberType>& left, const Point<MemberType>& right) {
	return right + left;
}

template <typename MemberType>
MemberType distance(const Point<MemberType>& point1, const Point<MemberType>& point2) {
	return (point2 - point1).magnitude();
}

template <typename MemberType>
Point<MemberType> center(const Point<MemberType>& point1, const Point<MemberType>& point2) {
	return point1 + (point2 - point1) / 2;
}

#endif /* POINT_H_ */
